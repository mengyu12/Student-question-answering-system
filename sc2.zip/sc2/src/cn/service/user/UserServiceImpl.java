package cn.service.user;

import java.sql.Connection;

import java.sql.SQLException;

import cn.pojo.User;
import cn.dao.user.*;
import dao.BaseDao;
import cn.dao.user.UserDao;
//袁婧
public class UserServiceImpl implements UserService {
    private UserDao userDao;
	
	public UserServiceImpl(){
		userDao = new UserDaoImpl();
	}
	
	public boolean add(User user) {
		// TODO Auto-generated method stub
				boolean flag = false;
				Connection connection = null;
				try {
					connection = BaseDao.getConnection();//连接数据库
					connection.setAutoCommit(false);//开启JDBC事务
					int updateRows = userDao.add(connection, user);//调用userDao.add
					
					connection.commit();
					
					if(updateRows>0){
						flag = true;
						System.out.println("add user success!");
					}else{
						System.out.println("add user failed!");
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					try {
						connection.rollback();
						flag = false;
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}finally{
					BaseDao.closeResource(connection, null, null);
				}
				return flag;
	}
	
	public boolean delUserById(String id) {
		boolean flag=false;
		Connection connection=null;
		try {
			connection = BaseDao.getConnection();
			flag = userDao.delUserById(connection, id);
		}catch(Exception e){
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			BaseDao.closeResource(connection, null, null);
		}
		return flag;
	}
	
	public boolean updateUser(User user)
	{
		boolean flag = false;
		Connection connection = null;
		try {
			connection = BaseDao.getConnection();
			flag = userDao.updateUser(connection, user);
		}catch(Exception e){
			e.printStackTrace();
		}finally {
			BaseDao.closeResource(connection, null, null);
		}
		return flag;
	}
	public User login(String id,String userPassword) {
		User user = null;
		Connection connection = null;
		try {
			connection = BaseDao.getConnection();
			user = userDao.getLoginUser(connection, id);
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			BaseDao.closeResource(connection, null, null);
		}
		
		if(user!=null)
		{
			if(!user.getPassword().equals(userPassword)){
			user=null;
			System.out.println("密码不对！");
			}
		}
		return user;
	}
	
	public boolean ucexist(String id) {
		boolean flag = false;
		Connection connection = null;
		try {
			connection = BaseDao.getConnection();
			flag = userDao.ucexist(connection, id);
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			BaseDao.closeResource(connection, null, null);
		}
		return flag;
	}
}
