package cn.service.user;

import cn.pojo.User;
//袁婧
public interface UserService {
	public boolean add(User user);//增加用户
	public boolean delUserById(String id);//根据id删除用户
	public boolean updateUser(User user);//更改用户信息
	public User login(String id,String userPassword);//登录验证，获取user
	public boolean ucexist(String id);//查询id是否存在
}
