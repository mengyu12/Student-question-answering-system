package cn.service.question;


import java.util.HashMap;
import java.util.List;

import cn.pojo.Problem;



public interface ProblemService {
	
	public boolean add(Problem problem);
	public boolean delUserById(String problemtitle);
	public boolean modifyUser(Problem user);
	public List<Problem> getPageUserList();
}
