package cn.service.question;

import java.sql.Connection;


import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;

import cn.dao.problem.*;
import cn.pojo.Problem;
import dao.BaseDao;



public class ProblemServiceImpl {
	private ProblemDao problemDao;
	
	public ProblemServiceImpl(){
		problemDao = new ProblemDaoImpl();
	}
	public boolean add(Problem problem) {
		// TODO Auto-generated method stub
		boolean flag = false;
		Connection connection = null;
		try {
			connection = BaseDao.getConnection();
			connection.setAutoCommit(false);
			int updateRows = problemDao.add(connection, problem);		
			connection.commit();
			if(updateRows>0){
				flag = true;
				System.out.println("add problem success!");
			}else{
				System.out.println("add problem failed!");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			try {
				connection.rollback();
				flag = false;
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}finally{
			 BaseDao.closeResource(connection, null, null);
		}
		return flag;
	}
	 
	public boolean delUserById(String problemtitle) {
		// TODO Auto-generated method stub
		boolean flag = false;
		Connection connection = null;
		try{
			connection =  BaseDao.getConnection();
			flag = problemDao.delUserById(connection, problemtitle);
		}catch(Exception e) {
			e.printStackTrace();
		}finally{
			 BaseDao.closeResource(connection, null, null);
		}
		return flag;
	}
	 
	 
	public boolean modifyUser(Problem user) {
		// TODO Auto-generated method stub
		boolean flag = false; 
		Connection connection = null;
		try {
			connection =  BaseDao.getConnection();
			String problemtitle;
			flag = problemDao.delUserById(connection, user.getProblemtitle());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			 BaseDao.closeResource(connection, null, null);
		}
		return flag;
	} 
	public List<Problem> getPageUserList() {
		// TODO Auto-generated method stub
		Connection connection = null;
		List<Problem> userList = null;
		try {
			connection =  BaseDao.getConnection();
			userList = problemDao.getPageUserList(connection);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			 BaseDao.closeResource(connection, null, null);
		}
		return userList;
	}

}
