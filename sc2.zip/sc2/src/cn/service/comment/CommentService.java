package cn.service.comment;

import java.util.HashMap;
import java.util.List;

import cn.pojo.Comment;

public interface CommentService {
	public boolean add(Comment comment);//增加评论
	public boolean delComment(Comment comment);//删除评论
	public boolean updateComment(Comment comment);//更改评论
	public Comment getComment(String id,String articletitle);//根据id和文章名获得评论
	public List<Comment> getPageCommentList(String articletitle,HashMap<String,Integer> pageInfo);
	public int getRecCountByName(String articletitle);
	public List<Comment> getCommentByArticle(String articletitle);
}
