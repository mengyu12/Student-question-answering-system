package cn.service.comment;

import java.sql.Connection;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;

import cn.dao.comment.*;
import cn.pojo.Article;
import cn.pojo.Comment;
import dao.BaseDao;

public class CommentServiceImpl implements CommentService{
    private CommentDao commentDao;
	
	public CommentServiceImpl(){
		commentDao = new CommentDaoImpl();
	}
	public boolean add(Comment comment)//增加评论
	{
		boolean flag = false;
		Connection connection = null;
		try {
			connection = BaseDao.getConnection();//连接数据库
			connection.setAutoCommit(false);//开启JDBC事务
			int updateRows = commentDao.add(connection, comment);
			
			connection.commit();
			
			if(updateRows>0){
				flag = true;
				System.out.println("add comment success!");
			}else{
				System.out.println("add comment failed!");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			try {
				connection.rollback();
				flag = false;
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}finally{
			BaseDao.closeResource(connection, null, null);
		}
		return flag;
	}
	public boolean delComment(Comment comment)//删除评论
	{
		boolean flag=false;
		Connection connection=null;
		try {
			connection = BaseDao.getConnection();
			flag = commentDao.delComment(connection, comment);
		}catch(Exception e){
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			BaseDao.closeResource(connection, null, null);
		}
		return flag;
	}
	public boolean updateComment(Comment comment)//更改评论
	{
		boolean flag = false;
		Connection connection = null;
		try {
			connection = BaseDao.getConnection();
			flag = commentDao.updateComment(connection, comment);
		}catch(Exception e){
			e.printStackTrace();
		}finally {
			BaseDao.closeResource(connection, null, null);
		}
		return flag;
	}
	public Comment getComment(String id,String articletitle)//根据id和文章名获得评论
	{
		Comment comment = null;
		Connection connection = null;
		try {
			connection = BaseDao.getConnection();
			comment = commentDao.getComment(connection, id, articletitle);
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			BaseDao.closeResource(connection, null, null);
		}
		
		if(comment!=null) {
			System.out.println("你并未评论该文章！");
		}
		
		return comment;
	}
	
	public List<Comment> getPageCommentList(String articletitle,HashMap<String,Integer> pageInfo)
	{
		Connection connection = null;
		List<Comment> commentList = null;
		try {
			connection = BaseDao.getConnection();
			commentList = commentDao.getPageCommentList(connection, articletitle, pageInfo);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			BaseDao.closeResource(connection, null, null);
		}
		return commentList;
	}

	public int getRecCountByName(String articletitle)
	{
		int recCount = 0;
		Connection connection = null;
		try {
			connection = BaseDao.getConnection();
			recCount = commentDao.getRecCountByName(connection, articletitle);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			BaseDao.closeResource(connection, null, null);
		}
		return recCount;
	}
	@Override
	public List<Comment> getCommentByArticle(String articletitle) {
		// TODO Auto-generated method stub
		Connection connection = null;
		List<Comment> CommentList = null;
		try {
			connection = BaseDao.getConnection();
			CommentList = commentDao.getCommentByArticle(connection, articletitle);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			BaseDao.closeResource(connection, null, null);
		}
		return CommentList;
	}
}
