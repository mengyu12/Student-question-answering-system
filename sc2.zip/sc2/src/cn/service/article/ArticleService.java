package cn.service.article;

import java.util.HashMap;
import java.util.List;
import cn.pojo.Article;
/**
 * 
 * @author 夏婉淇
 *
 */


public interface ArticleService {
	public boolean addarticle(Article article);//增加文章
	public boolean delArticleByArticleId(String id , String articletitle);//通过id和文章标题删除文章
	public boolean updateArticle(Article article);//更改文章信息
	public Article getArticle(String articletitle);//通过文章标题获取文章
	public List<Article> getPageArticleList(String articletitle,HashMap<String,Integer> pageInfo);//分页获取articleList
	public int getRecCountByarticletitle(String articletitle);//通过文章标题查询得到总记录条数
	public List<Article> getList();//获取所有文章列表
	public List<Article> getListByID(String id);//通过ID获取文章列表
	
	public List<Article> getListByTopic(String topic);//通过话题名获取文章列表

}
