package cn.service.article;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import cn.dao.article.ArticleDao;
import cn.dao.article.ArticleDaoImpl;
import cn.pojo.Article;
import dao.BaseDao;
/**
 * 
 * @author 夏婉淇
 *
 */

public  class ArticleServiceImpl implements ArticleService{
  private ArticleDao articleDao;
	
	public ArticleServiceImpl(){
		articleDao = new ArticleDaoImpl();
	}

	@Override
	public boolean addarticle(Article article) {
		// TODO Auto-generated method stub
		boolean flag = false;
		Connection connection = null;
		try {
			connection = BaseDao.getConnection();//连接数据库
			connection.setAutoCommit(false);//开启JDBC事务
			int updateRows = articleDao.addarticle(connection, article);//调用articleDao.addarticle
			
			connection.commit();
			
			if(updateRows>0){
				flag = true;
				System.out.println("add article success!");
			}else{
				System.out.println("add article failed!");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			try {
				connection.rollback();
				flag = false;
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}finally{
			BaseDao.closeResource(connection, null, null);
		}
		return flag;
		
	}

	@Override
	public boolean delArticleByArticleId(String id , String articletitle) {
		// TODO Auto-generated method stub
		boolean flag=false;
		Connection connection=null;
		try {
			connection = BaseDao.getConnection();
			flag = articleDao.delArticleByArticleId(connection, id, articletitle);
		}catch(Exception e){
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			BaseDao.closeResource(connection, null, null);
		}
		return flag;
		
	}

	@Override
	public boolean updateArticle(Article article) {
		// TODO Auto-generated method stub
		boolean flag = false;
		Connection connection = null;
		try {
			connection = BaseDao.getConnection();
			flag = articleDao.updateArticle(connection, article);
		}catch(Exception e){
			e.printStackTrace();
		}finally {
			BaseDao.closeResource(connection, null, null);
		}
		return flag;
		
	}

	@Override
	public Article getArticle(String articletitle) {
		// TODO Auto-generated method stub
				Article article = null;
		Connection connection = null;
		try {
			connection = BaseDao.getConnection();
			article  = articleDao.getArticle(connection, articletitle);
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			BaseDao.closeResource(connection, null, null);
		}
		
		if(article!= null)
		{
			System.out.println("文章存在！");}
		else {
			System.out.println("文章不存在！");
		}
		return article ;
		
	}
	@Override
	public List<Article> getPageArticleList(String articletitle,HashMap<String,Integer> pageInfo) {
		// TODO Auto-generated method stub
		Connection connection = null;
		List<Article> articleList = null;
		try {
			connection = BaseDao.getConnection();
			articleList = articleDao.getPageArticleList(connection, articletitle, pageInfo);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			BaseDao.closeResource(connection, null, null);
		}
		return articleList;
	}
	@Override
	public int getRecCountByarticletitle(String articletitle){
		// TODO Auto-generated method stub
		int recCount = 0;
		Connection connection = null;
		try {
			connection = BaseDao.getConnection();
			recCount = articleDao.getRecCountByarticletitle(connection, articletitle);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			BaseDao.closeResource(connection, null, null);
		}
		return recCount;
	}
	@Override
	public List<Article> getList() {
		// TODO Auto-generated method stub
		Connection connection = null;
		List<Article> ArticleList = null;
		try {
			connection = BaseDao.getConnection();
			 ArticleList = articleDao.getList(connection);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			BaseDao.closeResource(connection, null, null);
		}
		return ArticleList;
	}

	@Override
	public List<Article> getListByID( String id) {
		// TODO Auto-generated method stub
		Connection connection = null;
		List<Article> ArticleList = null;
		try {
			connection = BaseDao.getConnection();
			 ArticleList = articleDao.getListByID(connection,id);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			BaseDao.closeResource(connection, null, null);
		}
		return ArticleList;
	}
	
	@Override
	public List<Article> getListByTopic( String topic) {
		// TODO Auto-generated method stub
		Connection connection = null;
		List<Article> ArticleList = null;
		try {
			connection = BaseDao.getConnection();
			 ArticleList = articleDao.getListByTopic(connection,topic);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			BaseDao.closeResource(connection, null, null);
		}
		return ArticleList;
	}


	

}
