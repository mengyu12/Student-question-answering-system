package cn.service.answer;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import cn.dao.answer.AnswerDao;
import cn.dao.answer.AnswerDaoImpl;
import cn.pojo.Answer;
import dao.BaseDao;
/**
 * 
 * @author 夏婉淇
 *
 */

public class AnswerServiceImpl implements AnswerService{
  private AnswerDao answerDao;
	
	public AnswerServiceImpl(){
		answerDao = new AnswerDaoImpl();
	}

	@Override
	public boolean addanswer(Answer answer) {
		// TODO Auto-generated method stub
		boolean flag = false;
		Connection connection = null;
		try {
			connection = BaseDao.getConnection();//连接数据库
			connection.setAutoCommit(false);//开启JDBC事务
			int updateRows = answerDao.addanswer(connection, answer);//调用answerDao.addanswer
			
			connection.commit();
			
			if(updateRows>0){
				flag = true;
				System.out.println("add answer success!");
			}else{
				System.out.println("add answer failed!");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			try {
				connection.rollback();
				flag = false;
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}finally{
			BaseDao.closeResource(connection, null, null);
		}
		return flag;
		
	}

	@Override
	public boolean delAnswer(String id, String problemtitle) {
		// TODO Auto-generated method stub
		boolean flag=false;
		Connection connection=null;
		try {
			connection = BaseDao.getConnection();
			flag = answerDao.delAnswer(connection, id, problemtitle);
		}catch(Exception e){
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			BaseDao.closeResource(connection, null, null);
		}
		return flag;
		
		
		
	}
	@Override
	public List<Answer> getAnswerListByID( String id) {
		// TODO Auto-generated method stub
		Connection connection = null;
		List<Answer> AnswerList = null;
		try {
			connection = BaseDao.getConnection();
			 AnswerList = answerDao.getAnswerListByID(connection,id);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			BaseDao.closeResource(connection, null, null);
		}
		return AnswerList;
	}
	@Override
	public List<Answer> getAnswerListByTitle( String problemtitle) {
		// TODO Auto-generated method stub
		Connection connection = null;
		List<Answer> AnswerList = null;
		try {
			connection = BaseDao.getConnection();
			 AnswerList = answerDao.getAnswerListByTitle(connection,problemtitle);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			BaseDao.closeResource(connection, null, null);
		}
		return AnswerList;
	}

	

}
