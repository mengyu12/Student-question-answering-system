package cn.service.answer;

import java.util.List;
import cn.pojo.Answer;
/**
 * 
 * @author 夏婉淇
 *
 */


public interface AnswerService {
	public boolean addanswer(Answer answer);//增加回答
	public boolean delAnswer(String id , String problemtitle);//通过问题名和id删除回答
	public List<Answer> getAnswerListByID(String id);//通过ID获取回答列表
	public List<Answer> getAnswerListByTitle(String problemtitle);//通过问题名获取回答列表

}
