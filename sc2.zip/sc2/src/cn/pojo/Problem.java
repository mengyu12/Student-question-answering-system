package cn.pojo;

import java.sql.Date;

public class Problem {
	private int problemid;
	private String id;
	private String problemtitle;
	private String problemcontent;
	private Date problemdate;
	private String topic;
	public String getTopic() {
		return topic;
	}
	public void setTopic(String topic) {
		this.topic = topic;
	}
	public int getProblemid() {
		return problemid;
	}
	public void setProblemid(int problemid) {
		this.problemid = problemid;
	}
	public String getId() {
		return id;
	}
	public void setId(String userid) {
		this.id = userid;
	}
	public String getProblemtitle() {
		return problemtitle;
	}
	public void setProblemtitle(String problemtitle) {
		this.problemtitle = problemtitle;
	}
	public String getProblemcontent() {
		return problemcontent;
	}
	public void setProblemcontent(String problemcontent) {
		this.problemcontent = problemcontent;
	}
	public Date getProblemdate() {
		return problemdate;
	}
	public void setProblemdate(java.util.Date date) {
		this.problemdate = (Date) date;
	}
}
