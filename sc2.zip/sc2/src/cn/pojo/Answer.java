package cn.pojo;

import java.sql.Date;

public class Answer {
	private int answerid;
	private String id;
	
	private String problemtitle;
	private String answercontent;
	private Date answertime;
	private String panswerid;

	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getProblemtitle() {
		return problemtitle;
	}
	public void setProblemtitle(String problemtitle) {
		this.problemtitle = problemtitle;
	}
	public String getAnswercontent() {
		return answercontent;
	}
	public void setAnswercontent(String answercontent) {
		this.answercontent = answercontent;
	}
	public Date getAnswertime() {
		return answertime;
	}
	public void setAnswertime(Date answertime) {
		this.answertime = answertime;
	}
	public int getAnswerid() {
		return answerid;
	}
	public void setAnswerid(int answerid) {
		this.answerid = answerid;
	}
	
	
	public String getPanswerid() {
		return panswerid;
	}
	public void setPanswerid(String panswerid) {
		this.panswerid = panswerid;
	}
	
}
