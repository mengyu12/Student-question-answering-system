package cn.dao.answer;

import java.sql.Connection;
import java.util.List;
import cn.pojo.Answer;
/**
 * 
 * @author 夏婉淇
 *
 */

public interface AnswerDao {
	public int addanswer(Connection connection,Answer answer)throws Exception;//增加回答
	public boolean delAnswer(Connection connection,String id , String problemtitle)throws Exception;//通过问题名和id删除回答
	
	public List<Answer> getAnswerListByID(Connection connection,String id)throws Exception;//通过ID来获取回答列表
	public List<Answer> getAnswerListByTitle(Connection connection,String problemtitle)throws Exception;//通过问题名来获取回答列表
}
