package cn.dao.answer;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import cn.pojo.Answer;
import dao.BaseDao;
/**
 * 
 * @author 夏婉淇
 *
 */

public class AnswerDaoImpl implements AnswerDao{

	@Override
	public int addanswer(Connection connection, Answer answer) throws Exception {
		// TODO Auto-generated method stub
		int updateRows = 0;
		if(null!=connection){//是否连接上数据库
			PreparedStatement preparedStatement = null;
			String sql = "insert into sc_answer " +
					"(id,problemtitle,answercontent,answertime)" +
					"values(?,?,?,?);";
			//将新增回答数据给params
			Object[] params = {answer.getId(),answer.getProblemtitle(),answer.getAnswercontent(),answer.getAnswertime()};
			for(int i=0;i<params.length;i++)
				System.out.print(params[i]+" ");
			updateRows = BaseDao.execute(connection, preparedStatement, sql, params);//调用BaseDao.execute
			BaseDao.closeResource(null, preparedStatement, null);
		}
		System.out.println(updateRows);
		return updateRows;
		
	}

	@Override
	public boolean delAnswer(Connection connection, String id, String problemtitle) throws Exception {
		// TODO Auto-generated method stub
		boolean flag = false;
		PreparedStatement preparedStatement = null;
		if(connection != null){
			String sql = "delete from sc_answer where id=? and problemtitle=?";
			Object[] params = {id,problemtitle};
			if(BaseDao.execute(connection, preparedStatement, sql, params)>0){
				flag = true;
			}
			BaseDao.closeResource(null, preparedStatement, null);
		}
		return flag;
		
	}
	@Override
	public List<Answer> getAnswerListByID(Connection connection, String id) throws Exception {
		// TODO Auto-generated method stub
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		List<Answer> AnswerList =new ArrayList<Answer>();
		if(connection!=null){
			String sql = "select * from sc_answer where id=?";
			Object[] params = {id};
			resultSet = BaseDao.execute(connection, preparedStatement, resultSet, sql, params);
			while(resultSet.next()){
				Answer answer = new Answer();
				answer.setAnswerid(resultSet.getInt("answerid"));
				answer.setId(resultSet.getString("id"));
				answer.setProblemtitle(resultSet.getString("problemtitle"));
				answer.setAnswercontent(resultSet.getString("answercontent"));
				answer.setAnswertime(resultSet.getDate("answertime"));
				
				AnswerList.add(answer);
			}
			BaseDao.closeResource(null, preparedStatement, resultSet);
		}
		return AnswerList;
	}
	@Override
	public List<Answer> getAnswerListByTitle(Connection connection, String problemtitle) throws Exception {
		// TODO Auto-generated method stub
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		List<Answer> AnswerList =new ArrayList<Answer>();
		if(connection!=null){
			String sql = "select * from sc_answer where problemtitle=?";
			Object[] params = { problemtitle};
			resultSet = BaseDao.execute(connection, preparedStatement, resultSet, sql, params);
			while(resultSet.next()){
				Answer answer = new Answer();
				answer.setAnswerid(resultSet.getInt("answerid"));
				answer.setId(resultSet.getString("id"));
				answer.setProblemtitle(resultSet.getString("problemtitle"));
				answer.setAnswercontent(resultSet.getString("answercontent"));
				answer.setAnswertime(resultSet.getDate("answertime"));
				
				AnswerList.add(answer);
			}
			BaseDao.closeResource(null, preparedStatement, resultSet);
		}
		return AnswerList;
	}
}
