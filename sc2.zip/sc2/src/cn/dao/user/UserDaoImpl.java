package cn.dao.user;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import dao.BaseDao;
import cn.pojo.*;
//袁婧
public class UserDaoImpl implements UserDao{

		public int add(Connection connection, User user) throws Exception{
			// TODO Auto-generated method stub
			int updateRows = 0;
			if(null!=connection){//是否连接上数据库
				PreparedStatement preparedStatement = null;
				String sql = "insert into sc_user " +
						"(id,userName,password,userphone,email,userdepartment,usertype)" +
						"values(?,?,?,?,?,?,?);";
				//将新增用户数据给params
				Object[] params = {user.getId(),user.getUserName(),user.getPassword(),user.getUserphone(),user.getEmail(),user.getUserdepartment(),user.getUsertype()};
				for(int i=0;i<params.length;i++)
					System.out.print(params[i]+" ");
				updateRows = BaseDao.execute(connection, preparedStatement, sql, params);//调用BaseDao.execute
				BaseDao.closeResource(null, preparedStatement, null);
			}
			System.out.println(updateRows);
			return updateRows;
		}

		public boolean delUserById(Connection connection,String id)throws Exception{;
			boolean flag = false;
			PreparedStatement preparedStatement = null;
			if(connection != null){
				String sql = "delete from sc_user where id=?";
				Object[] params = {id};
				if(BaseDao.execute(connection, preparedStatement, sql, params)>0){
					flag = true;
				}
				BaseDao.closeResource(null, preparedStatement, null);
			}
			return flag;
		}
		
		public User getLoginUser(Connection connection,String id)throws Exception{
			User user = null;
			PreparedStatement preparedStatement = null;
			ResultSet resultSet = null;
			if(connection!=null) {
				String sql ="select * from sc_user where id=?";
				Object[] params = {id};
				resultSet = BaseDao.execute(connection, preparedStatement, resultSet, sql, params);
				if(resultSet.next()){
					user = new User();
					user.setId(resultSet.getString("id"));
					user.setUserName(resultSet.getString("userName"));
					user.setPassword(resultSet.getString("password"));
					user.setUserphone(resultSet.getString("userphone"));
					user.setEmail(resultSet.getString("email"));
					user.setUserdepartment(resultSet.getNString("userdepartment"));
					user.setUsertype(resultSet.getInt("usertype"));
				}
			}
			BaseDao.closeResource(null, preparedStatement, resultSet);
			return user;
		}
		
		public boolean updateUser(Connection connection,User user)throws Exception
		{
			boolean flag = false;
			PreparedStatement preparedStatement = null;
			if(connection!=null)
			{
				String sql = "update sc_user set userName=?,password=?,userphone=?,email=?,userdepartment=?,usertype=? where id=?";
				Object[] params = {user.getUserName(),user.getPassword(),user.getUserphone(),user.getEmail(),user.getUserdepartment(),user.getUsertype(),user.getId()};
				if(BaseDao.execute(connection, preparedStatement, sql, params)>0){
					flag = true;
				}
				BaseDao.closeResource(null, preparedStatement, null);
			}
			return flag;		
		}
		public boolean ucexist(Connection connection,String id)throws Exception
		{
			boolean flag = false;
			PreparedStatement preparedStatement = null;
			ResultSet resultSet = null;
			if(connection!=null)
			{
				String sql = "select count(1) from sc_user where id=?";
				Object[] params= {id};
				resultSet = BaseDao.execute(connection, preparedStatement, resultSet, sql, params);
				if(resultSet.next()){
					if(resultSet.getInt("count(1)")>0){
						flag = true;
					}
				}
				BaseDao.closeResource(null, preparedStatement, resultSet);
			}
			return flag;
			}
}
