package cn.dao.user;

import java.sql.Connection;

import java.util.HashMap;
import java.util.List;

import cn.pojo.User;


public interface UserDao {
	public int add(Connection connection,User user)throws Exception;//增加用户
	public boolean delUserById(Connection connection,String id)throws Exception;//通过id删除user
	public boolean updateUser(Connection connection,User user)throws Exception;//更改用户信息
	public User getLoginUser(Connection connection,String id)throws Exception;//通过id获取User
	public boolean ucexist(Connection connection,String id)throws Exception;//查询id是否存在
/*	public boolean updateUserPwdById(Connection connection,int id,String newPwd)throws Exception;//通过id修改密码
	public int getRecCountByName(Connection connection,String userName)throws Exception;//通过userName查询的用户
	public List<User> getPageUserList(Connection connection,String userName,HashMap<String,Integer> pageInfo)throws Exception;//分页获取pageUserList,通过userName模糊查询
*/
//袁婧
}
