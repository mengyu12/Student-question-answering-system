package cn.dao.problem;
import java.sql.Connection;
import java.util.HashMap;
import java.util.List;

import cn.pojo.Problem;
public interface ProblemDao {
	
	public  int add(Connection connection,Problem problem) throws Exception;
	public  boolean delUserById(Connection connection,String problemtitle)throws Exception;
	public  boolean modifyUser(Connection connection,Problem user)throws Exception;
	public  List<Problem> getPageUserList(Connection connection)throws Exception;
}
