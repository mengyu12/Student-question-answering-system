package cn.dao.problem;

import java.sql.Connection;


import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import cn.sc.tools.Constants;
import com.mysql.jdbc.PreparedStatement;


import cn.pojo.Problem;
import dao.BaseDao;

public class ProblemDaoImpl implements ProblemDao {
	public int add(Connection connection,  Problem problem) throws Exception{
		// TODO Auto-generated method stub
		int updateRows = 0;
		if(null!=connection){
			PreparedStatement preparedStatement = null;
			String sql="INSERT INTO sc_problem(id,problemtitle,problemcontent,problemdate,topic)"+
					"values(?,?,?,?,?)";
			Object[] params = {problem.getId(),problem.getProblemtitle(),problem.getProblemcontent(),problem.getProblemdate(),problem.getTopic()};
			for(int i=0;i<params.length;i++)
				System.out.print(params[i]+" ");
			updateRows = BaseDao.execute(connection, preparedStatement,sql, params);
			BaseDao.closeResource(null, preparedStatement, null);
		}
		System.out.println(updateRows);
		return updateRows;
	}

 

	public boolean delUserById(Connection connection, String problemtitle)
			throws Exception {
		// TODO Auto-generated method stub
		boolean flag = false;
		PreparedStatement preparedStatement = null;
		if(connection != null){
			String sql = "delete from sc_problem where problemtitle=?";
			Object[] params = {problemtitle};
			if(BaseDao.execute(connection, preparedStatement, sql, params)>0){
				flag = true;
			}
			BaseDao.closeResource(null, preparedStatement, null);
		}
		return flag;
	} 

	public boolean modifyUser(Connection connection, Problem user)
			throws Exception {
		// TODO Auto-generated method stub
		boolean flag = false;
		PreparedStatement preparedStatement = null;
		if(connection != null){
			String sql = "update sc_problem set problemcontent=?," +
					"topic=?" +
					" where problemtitle=?";
			Object[] params = {user.getId()};
			if(BaseDao.execute(connection, preparedStatement, sql, params)>0){
				flag = true;
			}
			BaseDao.closeResource(null, preparedStatement, null);
		}
		return flag;
	}
	public List<Problem> getPageUserList(Connection connection) throws Exception {
		// TODO Auto-generated method stub
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		List<Problem> userList =new ArrayList<Problem>();
		if(connection!=null){
			String sql = "select * from sc_problem";
			Object[] params = {};
			resultSet =BaseDao.execute(connection, preparedStatement, resultSet, sql, params);
			while(resultSet.next()){
				Problem user = new Problem();
				user.setId(resultSet.getString("id"));
				user.setProblemcontent(resultSet.getString("problemcontent"));
				user.setProblemtitle(resultSet.getString("problemtitle"));
				user.setTopic(resultSet.getString("topic")); 
				user.setProblemid(resultSet.getInt("problemid"));
				userList.add(user);
			}
			BaseDao.closeResource(null, preparedStatement, resultSet);
		}
		return userList;
	}

}
