package cn.dao.comment;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import cn.pojo.Comment;
import cn.sc.tools.Constants;
import dao.BaseDao;

public class CommentDaoImpl implements CommentDao{
	public int add(Connection connection,Comment comment)throws Exception//增加评论
	{
	int updateRows = 0;
	if(null!=connection){//是否连接上数据库
		PreparedStatement preparedStatement = null;
		String sql = "insert into sc_comment " +
				"(id,commenttime,commentcontent,articletitle)" +
				"values(?,?,?,?);";
		//将新增用户数据给params
		Object[] params = {comment.getId(),comment.getCommenttime(),comment.getCommentcontent(),comment.getArticletitle()};
		for(int i=0;i<params.length;i++)
			System.out.print(params[i]+" ");
		updateRows = BaseDao.execute(connection, preparedStatement, sql, params);//调用BaseDao.execute
		BaseDao.closeResource(null, preparedStatement, null);
	}
	    System.out.println(updateRows);
	    return updateRows;
	    }
	public boolean delComment(Connection connection,Comment comment)throws Exception//删除评论
	{
		boolean flag = false;
		PreparedStatement preparedStatement = null;
		if(connection != null){
			String sql = "delete from sc_comment where commentid=?";
			Object[] params = {comment.getCommentid()};
			if(BaseDao.execute(connection, preparedStatement, sql, params)>0){
				flag = true;
			}
			BaseDao.closeResource(null, preparedStatement, null);
		}
		return flag;
	}
	public boolean updateComment(Connection connection,Comment comment)throws Exception//更改评论
	{
		boolean flag = false;
		PreparedStatement preparedStatement = null;
		if(connection!=null)
		{
			String sql = "update sc_comment set commentcontent=?,commenttime=? where commentid=?";
			Object[] params = {comment.getCommentcontent(),comment.getCommenttime(),comment.getCommentid()};
			if(BaseDao.execute(connection, preparedStatement, sql, params)>0){
				flag = true;
			}
			BaseDao.closeResource(null, preparedStatement, null);
		}
		return flag;
	}
	public Comment getComment(Connection connection,String id,String articletitle)throws Exception//通过id和文章名获得评论
	{
		Comment comment = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		if(connection!=null) {
			String sql ="select * from sc_comment where id=? and articletitle=?";
			Object[] params = {id,articletitle};
			resultSet = BaseDao.execute(connection, preparedStatement, resultSet, sql, params);
			if(resultSet.next()){
				comment = new Comment();
				comment.setId(resultSet.getString("id"));
				comment.setCommentid(resultSet.getInt("commentid"));
				comment.setArticletitle(resultSet.getString("articletitle"));
				comment.setCommentcontent(resultSet.getString("commentcontent"));
				comment.setCommenttime(resultSet.getDate("commenttime"));
			}
		}
		BaseDao.closeResource(null, preparedStatement, resultSet);
		return comment;
	}
	
	public List<Comment> getPageCommentList(Connection connection,String articletitle,HashMap<String,Integer> pageInfo)throws Exception
	{
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		List<Comment> commentList =new ArrayList<Comment>();
		if(connection!=null){
			String sql = "select * from sc_comment where articletitle like ? order by commenttime desc limit ?,?";
			int startPageNo = pageInfo.get(Constants.PAGE_START_NO);
			int pageSize = pageInfo.get(Constants.PAGE_SIZE);
			startPageNo = (startPageNo - 1) * pageSize;
			Object[] params = {"%"+articletitle+"%",startPageNo,pageSize};
			resultSet = BaseDao.execute(connection, preparedStatement, resultSet, sql, params);
			while(resultSet.next()){
				Comment comment = new Comment();
				comment.setCommentid(resultSet.getInt("commentid"));
				comment.setArticletitle(articletitle);
				comment.setCommenttime(resultSet.getDate("commenttime"));
				comment.setId(resultSet.getString("id"));
				comment.setCommentcontent(resultSet.getString("commentcontent"));
				commentList.add(comment);
			}
			BaseDao.closeResource(null, preparedStatement, resultSet);
		}
		return commentList;
	}
	@Override
	public int getRecCountByName(Connection connection, String articletitle) throws Exception {
		// TODO Auto-generated method stub	
		int recCount = 0;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		if(connection != null){
			String sql = "select count(1) from sc_comment where articletitle like ?";
			Object[] params = {"%"+articletitle+"%"};
			resultSet = BaseDao.execute(connection, preparedStatement, resultSet, sql, params);
			if(resultSet.next()){
				recCount = resultSet.getInt("count(1)");
			}
			BaseDao.closeResource(null, preparedStatement, resultSet);
		}
		return recCount;
	}
	
	@Override
	public List<Comment> getCommentByArticle(Connection connection, String articletitle) throws Exception {
		// TODO Auto-generated method stub
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		List<Comment> CommentList =new ArrayList<Comment>();
		if(connection!=null){
			String sql = "select * from sc_comment where articletitle=?";
			Object[] params = {articletitle};
			resultSet = BaseDao.execute(connection, preparedStatement, resultSet, sql, params);
			while(resultSet.next()){
				Comment comment = new Comment();
				comment.setArticletitle(resultSet.getString("articletitle"));
				comment.setCommentcontent(resultSet.getString("commentcontent"));
				comment.setCommenttime(resultSet.getDate("commenttime"));
				comment.setId(resultSet.getString("id"));
				comment.setCommentid(resultSet.getInt("commentid"));
				CommentList.add(comment);
			}
			BaseDao.closeResource(null, preparedStatement, resultSet);
		}
		return CommentList;
	}
	
}
