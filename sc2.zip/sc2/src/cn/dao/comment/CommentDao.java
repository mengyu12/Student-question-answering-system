package cn.dao.comment;
import java.sql.Connection;


import java.util.HashMap;
import java.util.List;

import cn.pojo.Comment;
import cn.pojo.User;


public interface CommentDao {
	public int add(Connection connection,Comment comment)throws Exception;//增加
	public boolean delComment(Connection connection,Comment comment)throws Exception;//删除评论
	public boolean updateComment(Connection connection,Comment comment)throws Exception;//更改评论
	public Comment getComment(Connection connection,String id,String articletitle)throws Exception;//通过id和文章名获得评论
	public List<Comment> getPageCommentList(Connection connection,String articletitle,HashMap<String,Integer> pageInfo)throws Exception;
	public int getRecCountByName(Connection connection,String articletitle)throws Exception;
	public List<Comment> getCommentByArticle(Connection connection,String articletitle)throws Exception; 
	
}
