package cn.dao.article;
import java.sql.Connection;
import java.util.HashMap;
import java.util.List;
import cn.pojo.Article;
/**
 * 
 * @author 夏婉淇
 *
 */



public interface ArticleDao {
	public int addarticle(Connection connection,Article article)throws Exception;//增加文章
	public boolean delArticleByArticleId(Connection connection,String id , String articletitle)throws Exception;//通过文章标题删除文章
	public boolean updateArticle(Connection connection,Article article)throws Exception;//更改文章信息
	public List<Article> getPageArticleList(Connection connection,String articletitle,HashMap<String,Integer> pageInfo)throws Exception;//分页获取pageArticleList,通过文章标题模糊查询
	public int getRecCountByarticletitle(Connection connection,String articletitle)throws Exception;//通过文章标题查询得到总记录条数
    public Article getArticle(Connection connection,String articletitle) throws Exception;//通过文章标题获取文章
    public List<Article> getList(Connection connection)throws Exception;//获取所有文章列表
	public List<Article> getListByID(Connection connection,String id)throws Exception;//通过ID获取文章列表
	
	public List<Article> getListByTopic(Connection connection,String topic)throws Exception;//通过话题名获取文章列表

}
