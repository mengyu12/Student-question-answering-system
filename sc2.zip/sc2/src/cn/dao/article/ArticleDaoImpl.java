package cn.dao.article;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import cn.pojo.Article;
import cn.sc.tools.Constants;
import dao.BaseDao;
/**
 * 
 * @author 夏婉淇
 *
 */

public class ArticleDaoImpl implements ArticleDao{

	@Override
	public int addarticle(Connection connection, Article article) throws Exception {
		// TODO Auto-generated method stub
		int updateRows = 0;
		if(null!=connection){//是否连接上数据库
			PreparedStatement preparedStatement = null;
			String sql = "insert into sc_article " +
					"(id,articletitle,articlecontent,createdate,topic)" +
					"values(?,?,?,?,?);";
			//将新增文章数据给params
			Object[] params = {article.getId(),article.getArticletitle(),article.getArticlecontent(),article.getCreatedate(),article.getTopic()};
			for(int i=0;i<params.length;i++)
				System.out.print(params[i]+" ");
			updateRows = BaseDao.execute(connection, preparedStatement, sql, params);//调用BaseDao.execute
			BaseDao.closeResource(null, preparedStatement, null);
		}
		
		return updateRows;
		
	}

	@Override
	public boolean delArticleByArticleId(Connection connection,String id , String articletitle) throws Exception {
		// TODO Auto-generated method stub
		boolean flag = false;
		PreparedStatement preparedStatement = null;
		if(connection != null){
			String sql = "delete from sc_article where id=? and articletitle=?";
			Object[] params = {id,articletitle};
			if(BaseDao.execute(connection, preparedStatement, sql, params)>0){
				flag = true;
			}
			BaseDao.closeResource(null, preparedStatement, null);
		}
		return flag;
		
	}

	@Override
	public boolean updateArticle(Connection connection, Article article) throws Exception {
		// TODO Auto-generated method stub
		boolean flag = false;
		PreparedStatement preparedStatement = null;
		if(connection!=null)
		{
			String sql = "update sc_article set articlecontent=?,createdate=?,topic=? where articletitle=? and id=?";
			Object[] params = {article.getArticlecontent(),article.getCreatedate(),article.getArticletitle(),article.getId()};
			if(BaseDao.execute(connection, preparedStatement, sql, params)>0){
				flag = true;
			}
			BaseDao.closeResource(null, preparedStatement, null);
		}
		return flag;
		
	}

	
	@Override
	public List<Article> getPageArticleList(Connection connection,String articletitle,HashMap<String,Integer> pageInfo)throws Exception {
		// TODO Auto-generated method stub
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		List<Article> articleList =new ArrayList<Article>();
		if(connection!=null){
			String sql = "select * from sc_article where articletitle like ? order by createDate desc limit ?,?";
			int startPageNo = pageInfo.get(Constants.PAGE_START_NO);
			int pageSize = pageInfo.get(Constants.PAGE_SIZE);
			startPageNo = (startPageNo - 1) * pageSize;
			Object[] params = {"%"+articletitle+"%",startPageNo,pageSize};
			resultSet = BaseDao.execute(connection, preparedStatement, resultSet, sql, params);
			while(resultSet.next()){
				Article article = new Article();
				article.setId(resultSet.getString("id"));
				article.setArticletitle(resultSet.getString("articletitle"));
				article.setArticlecontent(resultSet.getString("articlecontent"));
				article.setCreatedate(resultSet.getDate("createdate"));
				article.setTopic(resultSet.getString("topic"));
				
				
				articleList.add(article);
			}
			BaseDao.closeResource(null, preparedStatement, resultSet);
		}
		return articleList;
	}

	@Override
	public int getRecCountByarticletitle(Connection connection,String articletitle)throws Exception
			{
		// TODO Auto-generated method stub
		int recCount = 0;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		if(connection != null){
			String sql = "select count(1) from sc_article where articletitle like ?";
			Object[] params = {"%"+articletitle+"%"};
			resultSet = BaseDao.execute(connection, preparedStatement, resultSet, sql, params);
			if(resultSet.next()){
				recCount = resultSet.getInt("count(1)");
			}
			BaseDao.closeResource(null, preparedStatement, resultSet);
		}
		return recCount;
	}
	@Override
	public Article getArticle(Connection connection,String articletitle) throws Exception
	{
		ResultSet resultSet = null;
		PreparedStatement preparedStatement = null;
		Article article = null;
		if(connection!=null) {
			String sql ="select * from sc_article where articletitle=?";
			Object[] params = {articletitle};
			resultSet = BaseDao.execute(connection, preparedStatement, resultSet, sql, params);
			if(resultSet.next()){
				article = new Article();
				article.setArticleid(resultSet.getInt("articleid"));
				article.setId(resultSet.getString("id"));
				article.setArticletitle(resultSet.getString("articletitle"));
				article.setArticlecontent(resultSet.getString("articlecontent"));
				article.setCreatedate(resultSet.getDate("createdate"));
				
			}
		}
		BaseDao.closeResource(null, preparedStatement, resultSet);
		return article;
		
	}
	@Override
	public List<Article> getList(Connection connection) throws Exception {
		// TODO Auto-generated method stub
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		List<Article> ArticleList =new ArrayList<Article>();
		if(connection!=null){
			String sql = "select * from sc_article";
			Object[] params = {};
			resultSet = BaseDao.execute(connection, preparedStatement, resultSet, sql, params);
			while(resultSet.next()){
				Article article = new Article();
				article.setArticlecontent(resultSet.getString("articlecontent"));
				article.setArticletitle(resultSet.getString("articletitle"));
				article.setId(resultSet.getString("id"));
				article.setArticleid(resultSet.getInt("articleid"));
				article.setCreatedate(resultSet.getDate("createdate"));
				ArticleList.add(article);
			}
			BaseDao.closeResource(null, preparedStatement, resultSet);
		}
		return ArticleList;
	}

	@Override
	public List<Article> getListByID(Connection connection, String id) throws Exception {
		// TODO Auto-generated method stub
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		List<Article> ArticleList =new ArrayList<Article>();
		if(connection!=null){
			String sql = "select * from sc_article where id=?";
			Object[] params = {id};
			resultSet = BaseDao.execute(connection, preparedStatement, resultSet, sql, params);
			while(resultSet.next()){
				Article article = new Article();
				article.setArticlecontent(resultSet.getString("articlecontent"));
				article.setArticletitle(resultSet.getString("articletitle"));
				article.setId(resultSet.getString("id"));
				article.setArticleid(resultSet.getInt("articleid"));
				article.setCreatedate(resultSet.getDate("createdate"));
				ArticleList.add(article);
			}
			BaseDao.closeResource(null, preparedStatement, resultSet);
		}
		return ArticleList;
	}
	
	@Override
	public List<Article> getListByTopic(Connection connection, String topic) throws Exception {
		// TODO Auto-generated method stub
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		List<Article> ArticleList =new ArrayList<Article>();
		if(connection!=null){
			String sql = "select * from sc_article where topic=?";
			Object[] params = {topic};
			resultSet = BaseDao.execute(connection, preparedStatement, resultSet, sql, params);
			while(resultSet.next()){
				Article article = new Article();
				article.setArticlecontent(resultSet.getString("articlecontent"));
				article.setArticletitle(resultSet.getString("articletitle"));
				article.setId(resultSet.getString("id"));
				article.setArticleid(resultSet.getInt("articleid"));
				article.setCreatedate(resultSet.getDate("createdate"));
				article.setTopic(resultSet.getString("topic"));
				ArticleList.add(article);
			}
			BaseDao.closeResource(null, preparedStatement, resultSet);
		}
		return ArticleList;
	}
	
}
