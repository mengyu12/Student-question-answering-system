package cn.servlet.answer;

import java.io.IOException;
import java.net.URLDecoder;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import cn.pojo.Answer;
import cn.service.answer.AnswerServiceImpl;
/**
 * @author 夏婉淇
 */

/**
 * Servlet implementation class getAnswerListByTitle
 */
@WebServlet("/getAnswerListByTitle")
public class getAnswerListByTitle extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public getAnswerListByTitle() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub		
		doPost(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setCharacterEncoding("UTF-8");
		request.setCharacterEncoding("UTF-8");
		response.setHeader("Content-type", "text/html;charset=UTF-8");
		String _problemtitle = new String(request.getParameter("problemtitle").getBytes("ISO-8859-1"),"utf-8"); 
		String _problemcontent = new String(request.getParameter("problemcontent").getBytes("ISO-8859-1"),"utf-8");
		request.setAttribute("problemtitle", _problemtitle);
		request.setAttribute("problemcontent", _problemcontent);
		System.out.println(_problemtitle);
		List<Answer> AnswerList = null;
		AnswerServiceImpl u = new AnswerServiceImpl();
		AnswerList =u.getAnswerListByTitle(_problemtitle);
		for(Answer a:AnswerList)
		{
			System.out.println(a.getAnswercontent());
		}
		request.setAttribute("AnswerList", AnswerList);
		request.getRequestDispatcher("problem1.jsp").forward(request, response);
	}

}
