package cn.servlet.question;

import java.io.IOException;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.pojo.Problem;
import cn.service.question.ProblemServiceImpl;

/**
 * Servlet implementation class addproblem
 */
@WebServlet("/addproblem")
public class addproblem extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public addproblem() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//鐠佸墽鐤嗙�涙顑�
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charest=UTF-8");
		//鏉烆剚宕茬�涙顑佹稉锟�
		//String _articleid=request.getParameter("articleid");
		String userid=request.getParameter("id");
		
		String _problemtitle = request.getParameter("problemtitle");
		String _problemcontent = request.getParameter("problemcontent");
	    String _topic=request.getParameter("topic");
		//int id = Integer.parseInt(_articleid);
		boolean flag=false;
		//鐠嬪啰鏁ervice鐎圭偟骞囨晶鐐插闂傤噣顣�
		if(_problemtitle!=null) {	
		ProblemServiceImpl u = new ProblemServiceImpl();
		Problem problem = new Problem();
		problem.setId(userid);
		//article.setArticleid(id);
		
		problem.setProblemtitle(_problemtitle);
		problem.setProblemcontent(_problemcontent);
		problem.setTopic(_topic );
		//problem.setProblemdate(new Date());
		java.util.Date utilDate = new java.util.Date(); //鑾峰彇褰撳墠鏃堕棿
		System.out.println(utilDate);
		java.sql.Date sqlDate = new java.sql.Date(utilDate.getTime());
		problem.setProblemdate(sqlDate);
		flag = u.add(problem);
		}
		if(flag) {
			request.getRequestDispatcher("index1.jsp").forward(request, response);
		}
		else {
			request.getRequestDispatcher("addproblem.jsp").forward(request, response);
		}
	}
	}


