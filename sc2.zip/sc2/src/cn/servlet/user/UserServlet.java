package cn.servlet.user;
import cn.pojo.User;
public class UserServlet {
	public void add(){
		String id = "2016210752";
		String userName = "yuanjing";
		String Password = "123456";
		String userphone = "12345678901";
		String email ="000000" ;
		String userdepartment="123";
	    int usertype=1;
		
		User user = new User();
		user.setId(id);
		user.setUserName(userName);
		user.setPassword(Password);
		user.setUserphone(userphone);
		user.setEmail(email);
		user.setUserdepartment(userdepartment);
		user.setUsertype(usertype);
	}

}
