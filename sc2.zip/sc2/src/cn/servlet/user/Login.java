package cn.servlet.user;

import java.io.IOException;


import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.pojo.User;
import cn.service.user.UserServiceImpl;
import cn.sc.tools.Constants;
//袁婧
/**
 * Servlet implementation class Login
 */
@WebServlet("/Login")
public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Login() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
        doPost(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		//设置字符
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charest=UTF-8");
		
		//转换字符串
		String _id=request.getParameter("id");
		String _password = request.getParameter("password");
		//调用service实现验证登录、增加注册
		UserServiceImpl u = new UserServiceImpl();
		User checkuser = null;
		checkuser = u.login(_id, _password);
		
		
		if(checkuser!=null)
		{
			//response.sendRedirect("/test/jsp/loginmain.jsp");
			request.getSession().setAttribute(Constants.USER_SESSION,checkuser);
			request.getRequestDispatcher("index1.jsp").forward(request, response);
		}else {
			//response.sendRedirect("/test/jsp/login.jsp");
			request.getRequestDispatcher("login.jsp").forward(request, response);
		}
		
	}

}
