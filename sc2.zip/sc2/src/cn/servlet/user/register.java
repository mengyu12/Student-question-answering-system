package cn.servlet.user;

import java.io.IOException;


import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import cn.service.user.*;
import cn.pojo.*;
import cn.sc.tools.Constants;
//袁婧
/**
 * Servlet implementation class register
 */
@WebServlet("/register")
public class register extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public register() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//设置字符
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		//转换字符串
		String _id=request.getParameter("id");
		String _password = request.getParameter("password");
		String _userName = request.getParameter("userName");
		//调用service实现验证登录、增加注册
		UserServiceImpl u = new UserServiceImpl();
		User user = new User();
		user.setId(_id);
		user.setPassword(_password);
		user.setUserName(_userName);
		
		boolean flag = u.add(user);
		if(flag) {
			//response.sendRedirect("/jsp/loginmain.jsp");
			request.getSession().setAttribute(Constants.USER_SESSION,user);
			request.getRequestDispatcher("index1.jsp").forward(request, response);
		}
		else {
			//response.sendRedirect("/jsp/registered.jsp");
			request.getRequestDispatcher("register.jsp").forward(request, response);
		}
	}

}
