package cn.servlet.comment;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.pojo.Comment;
import cn.service.comment.CommentServiceImpl;

/**
 * Servlet implementation class delCommentServlet
 */
@WebServlet("/delCommentServlet")
public class delCommentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public delCommentServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//设置字符
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charest=UTF-8");
		//转换字符串
		String _articletitle = request.getParameter("articletitle");
		String userid=request.getSession().getId();
		boolean flag=false;
		//调用service实现删除评论
		CommentServiceImpl u = new CommentServiceImpl();
		Comment comment = null;
		comment = u.getComment(userid, _articletitle);
		if(comment==null) {
			System.out.println("该评论不存在");
		}
		else {
			flag = u.delComment(comment);
			if(flag){
				request.getRequestDispatcher("index1.jsp").forward(request, response);
			}
			else{
				request.getRequestDispatcher("index1.jsp").forward(request, response);
			}
			
		}
		
	}

}
