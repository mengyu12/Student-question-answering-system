package cn.servlet.comment;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mysql.jdbc.StringUtils;
import cn.pojo.Comment;
import cn.service.comment.*;

import cn.sc.tools.Constants;
import cn.sc.tools.PageSupport;

/**
 * Servlet implementation class queryServlet
 */
@WebServlet("/queryServlet")
public class queryServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public queryServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String pageIndex = request.getParameter("pageIndex");
		String queryArticleTitle = request.getParameter("queryArticleTitle");
		if(queryArticleTitle==null){
			queryArticleTitle = "";
		}
		CommentServiceImpl commentService =  new CommentServiceImpl();
		int commentPageSize = Constants.COMMENT_PAGE_SIZE;
		//实例化PageSupport对象
		PageSupport pageSupport = new PageSupport();
		pageSupport.setPageSize(commentPageSize);
		//查询总记录数
		int recCount = commentService.getRecCountByName(queryArticleTitle);
		pageSupport.setRecCount(recCount);
		//设置当前页码
		int pageStartNo = 1;
		if(!StringUtils.isNullOrEmpty(pageIndex)){//设置当前页码
			pageStartNo = Integer.parseInt(pageIndex);
			if(pageStartNo<1){
				pageStartNo = 1;
			}else if(pageStartNo>pageSupport.getTotalPageCount()){
				pageStartNo = pageSupport.getTotalPageCount();
			}
		}
		pageSupport.setCurrPageNo(pageStartNo);
		//分页获取userlist
		HashMap<String,Integer> pageInfo = new HashMap<String,Integer>();
		pageInfo.put(Constants.PAGE_START_NO,Integer.valueOf(pageStartNo));
		pageInfo.put(Constants.PAGE_SIZE,Integer.valueOf(commentPageSize));
		List<Comment> commentList = commentService.getPageCommentList(queryArticleTitle, pageInfo);
		request.setAttribute("pageSupport",pageSupport);
		request.setAttribute("commentList",commentList);
		request.setAttribute("queryArticletitle",queryArticleTitle);
		request.getRequestDispatcher("jsp/userlist.jsp").forward(request, response);
	}

}
