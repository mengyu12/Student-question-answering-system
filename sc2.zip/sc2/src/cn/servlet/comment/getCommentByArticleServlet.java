package cn.servlet.comment;

import java.io.IOException;
import java.util.List;

import cn.pojo.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import cn.service.comment.*;
/**
 * Servlet implementation class getCommentByArticleServlet
 */
@WebServlet("/getCommentByArticleServlet")
public class getCommentByArticleServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public getCommentByArticleServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charest=UTF-8");
		String articletitle = request.getParameter("articletitle");
		CommentServiceImpl a = new CommentServiceImpl();
		List<Comment> CommentList = a.getCommentByArticle(articletitle);
		request.setAttribute("CommentList",CommentList);
		request.getRequestDispatcher("article1.jsp").forward(request, response);	
	}

}
