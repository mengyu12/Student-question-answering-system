package cn.servlet.article;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.pojo.Article;
import cn.service.article.ArticleServiceImpl;
//袁婧
/**
 * Servlet implementation class getListByIDServlet
 */
@WebServlet("/getListByIDServlet")
public class getListByIDServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	  /**
     * @see HttpServlet#HttpServlet()
     */
    public getListByIDServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String _id = request.getParameter("id");
		System.out.println(_id);
		List<Article> ArticleList = null;
		ArticleServiceImpl u = new ArticleServiceImpl();
		ArticleList =u.getListByID(_id);
		request.setAttribute("ArticleList", ArticleList);
		request.getRequestDispatcher("myarticlelist.jsp").forward(request, response);
	}

}
