package cn.servlet.article;

import java.io.IOException;

//import java.io.PrintWriter;
//import java.text.ParseException;
//import java.text.SimpleDateFormat;
//import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//import com.alibaba.fastjson.JSONArray;
import com.mysql.jdbc.StringUtils;

import cn.pojo.Article;
import cn.service.article.ArticleService;
import cn.service.article.ArticleServiceImpl;

import cn.sc.tools.*;

public class articlelist extends HttpServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * Constructor of the object.
	 */
	public articlelist() {
		super();
	}

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String method = request.getParameter("method");
		System.out.println("ArticleServlet---> "+method);
		if(method != null ){
			if(method.equals("query")){
				this.query(request, response);
			}
		}
	}

	//分页查询用户列表
	private void query(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String pageIndex = request.getParameter("pageIndex");
		String queryarticletitle = request.getParameter("queryarticletitle");
		if(queryarticletitle==null){
			queryarticletitle = "";
		}
		ArticleService articleService =  new ArticleServiceImpl();
		int articlePageSize = Constants.USER_PAGE_SIZE;
		//实例化PageSupport对象
		PageSupport pageSupport = new PageSupport();
		pageSupport.setPageSize(articlePageSize);
		//查询总记录数
		int recCount = articleService.getRecCountByarticletitle(queryarticletitle);
		pageSupport.setRecCount(recCount);
		//设置当前页码
		int pageStartNo = 1;
		if(!StringUtils.isNullOrEmpty(pageIndex)){//设置当前页码
			pageStartNo = Integer.parseInt(pageIndex);
			if(pageStartNo<1){
				pageStartNo = 1;
			}else if(pageStartNo>pageSupport.getTotalPageCount()){
				pageStartNo = pageSupport.getTotalPageCount();
			}
		}
		pageSupport.setCurrPageNo(pageStartNo);
		//分页获取articlelist
		HashMap<String,Integer> pageInfo = new HashMap<String,Integer>();
		pageInfo.put(Constants.PAGE_START_NO,Integer.valueOf(pageStartNo));
		pageInfo.put(Constants.PAGE_SIZE,Integer.valueOf(articlePageSize));
		List<Article> articleList = articleService.getPageArticleList(queryarticletitle, pageInfo);
		request.setAttribute("pageSupport",pageSupport);
		request.setAttribute("articleList",articleList);
		request.setAttribute("queryarticleList",queryarticletitle);
		request.getRequestDispatcher("/jsp/articlelist.jsp").forward(request, response);
	}
	
	/**
	 * Initialization of the userServlet. <br>
	 *
	 * @throws ServletException if an error occurs
	 */
	public void init() throws ServletException {
		// Put your code here
	}
}
