package cn.servlet.article;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import cn.pojo.Article;
import cn.service.article.ArticleServiceImpl;
/**
 * @author 夏婉淇
 */

/**
 * Servlet implementation class getArticleServlet
 */
@WebServlet("/getArticleServlet")
public class getArticleServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public getArticleServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//设置字符
				request.setCharacterEncoding("UTF-8");
				response.setCharacterEncoding("UTF-8");
				response.setContentType("text/html;charest=UTF-8");
				//转换字符串
				String _articletitle = new String(request.getParameter("articletitle").getBytes("ISO-8859-1"),"utf-8");
				Article article = new Article();
				ArticleServiceImpl u = new ArticleServiceImpl();
				article=u.getArticle(_articletitle);
				request.setAttribute("article", article);
				request.getRequestDispatcher("article1.jsp").forward(request, response);
						
	}

}
