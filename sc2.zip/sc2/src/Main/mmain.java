package Main;

import java.sql.Connection;

import cn.service.user.*;
import cn.dao.user.UserDaoImpl;
import cn.pojo.User;
import dao.BaseDao;

public class mmain {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		String id = "2016210752";
//		String userName = "xiaomi";
		//String Password = "123456";
/*		String prpassword ="123456";
		String userphone = "12345678901";
		String email ="000000" ;
		String userdepartment="123";
	    int usertype=1;*/
		
		User user = new User();
		user.setId(id);
/*		user.setUserName(userName);
		user.setPassword(Password);
		user.setPrpassword(prpassword);
		user.setUserphone(userphone);
		user.setEmail(email);
		user.setUserdepartment(userdepartment);
		user.setUsertype(usertype);*/
		UserServiceImpl a=new UserServiceImpl();
//		Connection c = BaseDao.getConnection();
//	    boolean f= false;
//		a.add(c, user);
//	    f = a.delUserById(c, id);

	    a.add( user);
//	    f =  a.delUserById(id);
//	    f = a.ucexist(id);
//		System.out.println(f);
/*		User user = null;
		user = a.getLoginUser(c, id);
		System.out.println(user.getId()+" "+user.getPassword());*/

	}

}
