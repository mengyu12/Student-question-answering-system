﻿package dao;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class BaseDao {
	
	public static Connection getConnection() {
		//
				try {
					Class.forName("com.mysql.jdbc.Driver");
					System.out.println("成功加载sql驱动");
				}catch(ClassNotFoundException e) {
					System.out.println("无法加载sql驱动！");
					e.printStackTrace();
				}
				//����URLΪ   jdbc:mysql//端口/数据库名
				String url="jdbc:mysql://localhost:3306/sc";
				Connection conn=null;
				try {
					conn = (Connection) DriverManager.getConnection(url,"root" , "123456");
					Statement stmt =(Statement) conn.createStatement();
					System.out.println("成功连接到数据库！");
/*					ResultSet rs = stmt.executeQuery("selete * from sc_user");
					System.out.println(rs.toString());
					while(rs.next()) {
						System.out.println(rs.getString("userName"));
					}
					
				stmt.close();
					conn.close();*/
				}catch(SQLException e) {
					System.out.println("fail to connect the database!");
					e.printStackTrace();
				}
				return conn;
	}
	
	/**
	 * 查询操作
	 * @param connection
	 * @param preparedStatement
	 * @param resultSet
	 * @param sql
	 * @param params
	 * @return
	 * @throws SQLException 
	 */
	public static ResultSet execute(Connection connection,PreparedStatement preparedStatement,ResultSet resultSet,String sql,Object[] params) throws SQLException{
		preparedStatement = connection.prepareStatement(sql);
		for(int i=0;i<params.length;i++){
			preparedStatement.setObject(i+1, params[i]);
		}
		resultSet = preparedStatement.executeQuery();
		return resultSet;
	}
	/**
	 * 更新操作
	 * @param connection
	 * @param preparedStatement
	 * @param resultSet
	 * @return
	 * @throws SQLException 
	 */
	public static int execute(Connection connection,PreparedStatement preparedStatement,String sql,Object[] params) throws SQLException{
		int updateRows = 0;
		preparedStatement = connection.prepareStatement(sql);//�õ�Ԥ�����sql���Ķ���
		for(int i=0;i<params.length;i++){
			preparedStatement.setObject(i+1,params[i]);
		}
		updateRows = preparedStatement.executeUpdate();
		return updateRows;
	}
	/**
	 * 关闭数据库
	 * @param connection
	 * @param preparedStatement
	 * @param resultSet
	 * @return
	 */
	public static boolean closeResource(Connection connection,PreparedStatement preparedStatement,ResultSet resultSet){  
        boolean flag=true;  
        if (resultSet!=null) {  
            try {  
                resultSet.close();  
                resultSet=null;//GC回收  
            } catch (SQLException e) {  
                // TODO Auto-generated catch block  
                e.printStackTrace();  
                flag=false;  
            }  
        }   
        
        if (preparedStatement!=null) {  
            try {  
                preparedStatement.close();  
                preparedStatement=null;//GC回收 
            } catch (SQLException e) {  
                // TODO Auto-generated catch block  
                e.printStackTrace();  
                flag=false;  
           }  
        } 
       
        if (connection!=null) {  
            try {  
                connection.close();  
                connection=null;//GC回收  
            } catch (SQLException e) {  
                // TODO Auto-generated catch block  
                e.printStackTrace();  
                flag=false;  
            }  
        }  
          
        return flag;  
    }

}
